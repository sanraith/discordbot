This functions from Libsodium have not yet been implemented in node-sodium
If you really need them please create a pull request and I will merge it in. Thank you for supporting the effort!
    
  * randombytes_implementation_name
  * randombytes_set_implementation
  * sodium_allocarray
  * sodium_free
  * sodium_malloc
  * sodium_mlock
  * sodium_mprotect_noaccess
  * sodium_mprotect_readonly
  * sodium_mprotect_readwrite
  * sodium_munlock
  
Deprecated Functions
  
  * crypto_sign_edwards25519sha512batch
  * crypto_sign_edwards25519sha512batch_keypair
  * crypto_sign_edwards25519sha512batch_open
  
