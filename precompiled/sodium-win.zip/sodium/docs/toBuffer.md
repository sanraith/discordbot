toBuffer(value, \[encoding\])
-----------------------------
Convert value into a buffer



**Parameters**

**value**:  *String|Buffer|Array*,  a buffer, and array of bytes or a string that you want to convert to a buffer

**[encoding]**:  *String*,  encoding to use in conversion if value is a string. Defaults to 'hex'

